
{{- define "artemis.name"}}
{{- $global := default (dict) .Values.global -}}
{{- $base := default .Chart.Name .Values.nameOverride -}}
{{- $gpre := default "" $global.namePrefix -}}
{{- $pre := default "" .Values.namePrefix -}}
{{- $suf := default "" .Values.nameSuffix -}}
{{- $gsuf := default "" $global.nameSuffix -}}
{{- $name := print $gpre $pre $base $suf $gsuf -}}
{{- $name | lower | trunc 54 | trimSuffix "-" -}}
{{- end -}}

{{- define "artemis.fullname"}}
{{- $global := default (dict) .Values.global -}}
{{- $base := default (printf "%s-%s" ( .Release.Name | trunc 29 | trimSuffix "-" ) .Chart.Name) .Values.fullnameOverride -}}
{{- $gpre := default "" $global.fullnamePrefix -}}
{{- $pre := default "" .Values.fullnamePrefix -}}
{{- $suf := default "" .Values.fullnameSuffix -}}
{{- $gsuf := default "" $global.fullnameSuffix -}}
{{- $name := print $gpre $pre $base $suf $gsuf -}}
{{- $name | lower | trunc 54 | trimSuffix "-" -}}
{{- end -}}

{{- define "artemis.image" -}}
{{- $registryName :=  .Values.image.registry -}}
{{- $repositoryName := .Values.image.repository -}}
{{- $tag := default .Chart.AppVersion .Values.image.tag | toString -}}
{{- printf "%s/%s:%s" $registryName $repositoryName $tag -}}
{{- end -}}

{{- define "artemis.databaseConnection" -}}
    {{- if .Values.artemis.broker.database.db_url -}}
    {{- .Values.artemis.broker.database.db_url -}}
    {{- else -}}
        {{- if eq .Values.artemis.broker.database.engine "postgres" -}}
        {{- printf "%s%s%s%v%s%s" "jdbc:postgresql://" .Values.artemis.broker.database.host ":" .Values.artemis.broker.database.port "/" .Values.artemis.broker.database.instance -}}
        {{- else if eq .Values.artemis.broker.database.engine "oracle" -}}
        {{- printf "%s%s%s%v%s%s" "jdbc:oracle:thin:@" .Values.artemis.broker.database.host ":" .Values.artemis.broker.database.port "/" .Values.artemis.broker.database.instance -}}
        {{- else if eq .Values.artemis.broker.database.engine "mssql" -}}
        {{- printf "%s%s%s%v%s%s%s" "jdbc:sqlserver://" .Values.artemis.broker.database.host ":" .Values.artemis.broker.database.port ";databaseName=" .Values.artemis.broker.database.instance ";encrypt=false" -}}
        {{ end }}
    {{- end -}}
{{- end -}}

{{- define "artemis.databaseDriver" -}}
{{ if eq .Values.artemis.broker.database.engine "postgres" }}
{{- "org.postgresql.Driver" -}}
{{else if eq .Values.artemis.broker.database.engine "oracle" }}
{{- "oracle.jdbc.driver.OracleDriver" -}}
{{else if eq .Values.artemis.broker.database.engine "mssql" }}
{{- "com.microsoft.sqlserver.jdbc.SQLServerDriver" -}}
{{ end }}
{{- end -}}

{{- define "artemis.databaseUsername" -}}
{{- if .Values.artemis.broker.database.username -}}
{{- .Values.artemis.broker.database.username | b64enc -}}
{{- else -}}
{{- "artemis" | b64enc -}}
{{- end -}}
{{- end -}}

{{- define "artemis.databasePassword" -}}
{{- if .Values.artemis.broker.database.password -}}
{{- .Values.artemis.broker.database.password | b64enc -}}
{{- else -}}
{{- "artemis" | b64enc -}}
{{- end -}}
{{- end -}}


{{- define "artemis.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}


{{- define "artemis.labels" -}}
app.kubernetes.io/name: {{ include "artemis.name" . }}
helm.sh/chart: {{ include "artemis.chart" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{- define "artemis.global-max-size" -}}
{{- if lt (regexFind "^[0-9]+" (.Values.artemis.primary.resources.limits.memory) | int )  5 -}}
{{- "1Gb" -}}
{{- else -}}
{{- printf "%d%s%s" (div (regexFind "[0-9]*" (.Values.artemis.primary.resources.limits.memory)) 5) (.Values.artemis.primary.resources.limits.memory | regexFind "[a-zA-Z]") "b" -}}
{{- end -}}
{{- end -}}